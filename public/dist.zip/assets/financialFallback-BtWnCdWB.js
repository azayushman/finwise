const t=["code","python","javascript","html","css","react","java","c++","sql","programming","recipe","cook","bake","physics","biology","chemistry","history","poem","story","essay","lyrics","movie","cricket","football","weather","translate","joke"],s=["hi","hello","hey","good morning","good evening","who are you","what can you do","help"],a=["finance","budget","save","saving","invest","investing","stock","mutual fund","sip","fd","ppf","nps","interest","compound","debt","loan","emi","credit","card","cibil","score","tax","emergency","salary","expense","spend","inflation","wealth","bank","retirement","etf","index fund","asset","liability","net worth","gold","insurance","50/30/20","rule of 72","lumpsum","broker","afford"];function r(i){const e=i.toLowerCase().trim();return t.some(n=>e.includes(n))?`I am FinWise, specialized exclusively in personal finance and money management. I cannot assist with non-financial topics like programming, general trivia, recipes, or creative writing.

Please feel free to ask any question about budgeting, saving, debt payoff, or investing basics!`:s.some(n=>e===n||e.startsWith(n+" "))?`Hello! I am FinWise, your personal finance education mentor. You can ask me anything about:

• The **50/30/20 budgeting rule**
• How **SIP and compound growth** work
• Building a resilient **emergency fund**
• Managing or paying down **high-interest credit debt**

What would you like to unpack today?`:a.some(n=>e.includes(n))?e.includes("50/30/20")||e.includes("budget")?`The **50/30/20 rule** is an intuitive budgeting framework:

• **50% Needs**: Essential living costs like rent, groceries, and basic utilities.
• **30% Wants**: Discretionary spending like dining out, entertainment, and hobbies.
• **20% Savings & Debt**: Emergency funds, investments (e.g. SIPs/Index funds), or paying down high-interest debt.

It offers a sustainable baseline for students and young professionals without tracking every single cent!`:e.includes("sip")||e.includes("compound")||e.includes("invest")?`A **Systematic Investment Plan (SIP)** invests a fixed sum regularly (e.g., monthly) into mutual funds or index funds.

**Why it works:**
1. **Rupee Cost Averaging**: You buy more units when market prices drop, and fewer when prices rise, averaging out volatility.
2. **Compound Interest**: Returns generate their own returns over time. Starting early is far more impactful than investing large sums later in life!`:e.includes("emergency")||e.includes("fund")?`An **Emergency Fund** is cash set aside exclusively for unexpected financial shocks (medical emergencies, unexpected vehicle repairs, or sudden job loss).

• **Ideal size**: 3 to 6 months of mandatory living expenses (rent + food + utilities).
• **Where to park it**: High-liquidity, low-risk accounts like a savings account or short-term fixed deposit (FD), not volatile stocks!`:e.includes("debt")||e.includes("credit card")||e.includes("loan")?`When managing debt, prioritize paying off **high-interest debt** (like credit cards with 36-42% APR) immediately.

Two proven debt payoff strategies:
• **Avalanche method**: Pay minimums on all loans, and put extra money toward the loan with the highest interest rate. Mathematically saves the most money.
• **Snowball method**: Pay off the smallest balance first for quick psychological momentum!`:"Personal finance is built on three core pillars: spending less than you earn, keeping an emergency cushion of 3-6 months of expenses, and consistently investing the surplus in low-cost index funds or SIPs to beat inflation over the long run.":"I am FinWise, specialized exclusively in personal finance and money management. I can only assist with questions about budgeting, saving, debt payoff, investing, and financial literacy. How can I help you with your financial planning today?"}export{r as getClientFinancialAnswer};
